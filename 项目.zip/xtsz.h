#ifndef XTSZ_H
#define XTSZ_H
void xtsz();
#endif // XTSZ_H
