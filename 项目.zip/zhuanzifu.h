#ifndef ZHUANZIFU_H
#define ZHUANZIFU_H
#include<string>
std::string zhuzifu( int n  );
#endif // ZHUANZIFU_H
