#ifndef SETTING_H
#define SETTING_H
void setting();
#endif // SETTING_H
