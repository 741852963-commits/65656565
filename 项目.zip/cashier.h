#ifndef CASHIER_H
#define CASHIER_H
void cashier();
#endif // CASHIER_H
