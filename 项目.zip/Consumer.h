#ifndef CONSUMER_H
#define CONSUMER_H
void Consumer();
#endif // CONSUMER_H
