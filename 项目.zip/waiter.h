#ifndef WAITER_H
#define WAITER_H
void waiter();
#endif // WAITER_H
