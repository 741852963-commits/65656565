#ifndef BOSS_H
#define BOSS_H
void boss();
#endif // BOSS_H
