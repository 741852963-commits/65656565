#ifndef COOK1_H
#define COOK1_H
void cook1();
#endif // COOK1_H
